# Supplementary Code: PPOAvg and Fed-AMPO-PPO

This archive contains an anonymized supplementary code bundle for the PPO-based
federated reinforcement learning experiments.

## Included

- `ppo_avg`: FedAvg-style PPO synchronization.
- `fed_ampo_ppo`: Fed-AMPO-PPO. The public class aliases are `FedAMPPO` and
  `FedAMPOPPO`; the capped/worst-group variant is implemented in the same file
  via `dual_lambda_cap`.
- Core RL Baselines3 Zoo training utilities needed to run the above algorithms.
- Federated execution utilities in `rl_zoo3/algorithms/federate/common`.
- Perturbed Gymnasium environments registered by `rl_zoo3/register.py`.
- Hyperparameter files for standard SB3 baselines plus `ppo_avg` and
  `fed_ampo_ppo`.

## Excluded

The bundle intentionally excludes other local research algorithms and outputs,
including SVRPGM, FedSP-PG, off-policy federated algorithms, protester/ICML/
NeurIPS experiment code, logs, W&B run directories, PDFs, patch files, cached
bytecode, and local machine metadata.

## Example Commands

```bash
python train.py --algo ppo_avg --env PerturbPendulum-v1 --frl --log-wandb False
python train.py --algo fed_ampo_ppo --env PerturbPendulum-v1 --frl --log-wandb False
```

For custom perturbation settings, pass environment kwargs in the same style as
RL Baselines3 Zoo:

```bash
python train.py --algo fed_ampo_ppo --env PerturbHopper-v4 --frl \
  --env-kwargs noise_type:gravity noise:0.2 --log-wandb False
```

## Notes

- W&B logging is disabled by default in this supplementary copy. Enable it only
  with explicit `--track` or `--log-wandb True` arguments.
- This code builds on RL Baselines3 Zoo and keeps its MIT license file.
