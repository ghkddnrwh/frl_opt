from rl_zoo3.algorithms.federate.ppo_avg.ppo_avg import PPOAvg

__all__ = ["PPOAvg"]
