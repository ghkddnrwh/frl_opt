from rl_zoo3.algorithms.federate.ampo import FedAMPPO, FedAMPOPPO
from rl_zoo3.algorithms.federate.ppo_avg.ppo_avg import PPOAvg

FEDERATE_ALGOS = {
    "fed_ampo_ppo": FedAMPPO,
    "ppo_avg": PPOAvg,
}

__all__ = [
    "PPOAvg",
    "FedAMPPO",
    "FedAMPOPPO",
]
