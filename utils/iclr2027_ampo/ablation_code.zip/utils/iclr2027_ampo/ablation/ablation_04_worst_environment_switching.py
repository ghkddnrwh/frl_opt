from __future__ import annotations

import numpy as np

from ampo_ablation_common import (
    ADAPTIVE_VARIANTS,
    ENV_ORDER,
    PERTURBATION_ORDER,
    DISPLAY_ENV,
    SHORT_VARIANT,
    apply_publication_style,
    common_parser,
    dominant_share,
    find_server_indices_for_eval_rounds,
    format_pm,
    get_group_runs,
    group_specs,
    load_group,
    make_latex_table_rows,
    summarize_seed_values,
    switch_rate,
    validate_expected_layout,
    write_csv,
    write_text,
)


# =============================================================================
# Variants
# =============================================================================
#
# 실제 로그 디렉토리 이름:
#
#   ampo_uniform
#   ampo_adaptive_dual_lr_1e-4
#   ampo_adaptive_dual_lr_3e-4
#
# 따라서 Uniform variant key는 "uniform"이 아니라 "ampo_uniform"이다.
# =============================================================================

UNIFORM_VARIANT = "ampo_uniform"

TRACKING_VARIANTS = (
    UNIFORM_VARIANT,
    *ADAPTIVE_VARIANTS,
)


def variant_short_name(
    variant: str,
) -> str:
    """
    LaTeX table에 사용할 method 이름.
    """
    if variant == UNIFORM_VARIANT:
        return "AMPO-PPO(U)"

    if variant in SHORT_VARIANT:
        return SHORT_VARIANT[
            variant
        ]

    return variant


# =============================================================================
# Lambda metrics
# =============================================================================


def effective_num_clients(
    lambda_weights: np.ndarray,
) -> np.ndarray:
    """
    Compute

        K_eff(t) = 1 / sum_k lambda_k(t)^2

    for each row.

    Uniform over K clients:
        lambda_k = 1/K
        -> K_eff = K

    Fully concentrated:
        lambda = [1, 0, ..., 0]
        -> K_eff = 1
    """
    lambda_weights = np.asarray(
        lambda_weights,
        dtype=float,
    )

    denom = np.sum(
        np.square(
            lambda_weights
        ),
        axis=1,
    )

    out = np.full(
        len(denom),
        np.nan,
        dtype=float,
    )

    valid = (
        np.isfinite(
            denom
        )
        & (denom > 0.0)
    )

    out[
        valid
    ] = (
        1.0
        / denom[
            valid
        ]
    )

    return out


def tie_aware_top1_match(
    lambda_weights: np.ndarray,
    worst_ids: np.ndarray,
) -> float:
    """
    Tie-aware Top-1 Match.

    기존 방식:

        argmax(lambda) == worst_client

    은 Uniform에서 부적절하다.

    예:
        lambda = [0.2, 0.2, 0.2, 0.2, 0.2]

    np.argmax는 무조건 client 0을 반환하므로,
    실제 의미 없는 tie-breaking 결과가 된다.

    여기서는 maximum lambda를 갖는 client가 m개이고,
    worst client가 그 집합에 포함될 경우

        1 / m

    을 부여한다.

    따라서 완전 Uniform + K=5이면:

        Top-1 Match = 0.2

    Adaptive에서 maximum lambda가 unique하면
    기존 0/1 Top-1 Match와 동일하다.
    """
    lambda_weights = np.asarray(
        lambda_weights,
        dtype=float,
    )

    worst_ids = np.asarray(
        worst_ids,
        dtype=int,
    ).reshape(-1)

    if lambda_weights.ndim != 2:
        raise ValueError(
            "lambda_weights must be 2D, "
            f"got {lambda_weights.shape}"
        )

    if len(lambda_weights) != len(worst_ids):
        raise ValueError(
            "lambda_weights and worst_ids must "
            "have the same number of rows."
        )

    if len(worst_ids) == 0:
        return np.nan

    row_max = np.max(
        lambda_weights,
        axis=1,
        keepdims=True,
    )

    top_mask = np.isclose(
        lambda_weights,
        row_max,
        rtol=1e-7,
        atol=1e-10,
    )

    num_top = np.sum(
        top_mask,
        axis=1,
    )

    scores = np.full(
        len(worst_ids),
        np.nan,
        dtype=float,
    )

    for t, worst_id in enumerate(
        worst_ids
    ):
        if (
            worst_id < 0
            or worst_id >= lambda_weights.shape[1]
        ):
            continue

        if num_top[t] <= 0:
            continue

        if top_mask[
            t,
            worst_id,
        ]:
            scores[t] = (
                1.0
                / float(
                    num_top[t]
                )
            )
        else:
            scores[t] = 0.0

    valid = np.isfinite(
        scores
    )

    if not np.any(valid):
        return np.nan

    return float(
        np.mean(
            scores[valid]
        )
    )


# =============================================================================
# Per-seed metrics
# =============================================================================


def per_seed_compact_metrics(
    run: dict[str, np.ndarray],
) -> dict[str, float]:
    """
    Compute full-trajectory worst-environment diagnostics.

    Metrics
    -------
    1. Worst Switch (Full)

       Fraction of consecutive evaluation points where
       the worst client identity changes.

    2. Dominant Worst Share (Full)

       Fraction of evaluations occupied by the client
       that is worst most frequently.

    3. Top-1 Match (Full)

       Tie-aware alignment between worst client and
       largest lambda weight.

       For exact Uniform weighting with K clients:
           Top-1 Match = 1/K

    4. K_eff (Full)

       Mean over matched points of

           1 / sum_k lambda_k^2

       For exact Uniform weighting:
           K_eff = K

    Each seed is reduced to one scalar per metric first.
    Final table reports mean +- std across seeds.
    """
    (
        e_idx,
        s_idx,
    ) = find_server_indices_for_eval_rounds(
        run
    )

    if len(e_idx) < 2:
        return {}

    # -------------------------------------------------------------------------
    # Evaluation returns
    # -------------------------------------------------------------------------

    eval_local = np.asarray(
        run["eval_local"],
        dtype=float,
    )[
        e_idx
    ]

    # -------------------------------------------------------------------------
    # Lambda used by actor/server aggregation
    #
    # IMPORTANT:
    # ampo_uniform cache에도 lambda_actor가 실제 저장되어 있다.
    #
    # 확인된 값 예:
    #     [0.2, 0.2, 0.2, 0.2, 0.2]
    # -------------------------------------------------------------------------

    lambda_actor = np.asarray(
        run["lambda_actor"],
        dtype=float,
    )[
        s_idx
    ]

    if eval_local.ndim != 2:
        raise ValueError(
            "eval_local must be 2D, "
            f"got {eval_local.shape}"
        )

    if lambda_actor.ndim != 2:
        raise ValueError(
            "lambda_actor must be 2D, "
            f"got {lambda_actor.shape}"
        )

    if (
        eval_local.shape[1]
        != lambda_actor.shape[1]
    ):
        raise ValueError(
            "Client-count mismatch: "
            f"eval_local has {eval_local.shape[1]}, "
            f"lambda_actor has {lambda_actor.shape[1]}."
        )

    # -------------------------------------------------------------------------
    # Keep only fully finite matched rows
    # -------------------------------------------------------------------------

    valid_rows = (
        np.all(
            np.isfinite(
                eval_local
            ),
            axis=1,
        )
        & np.all(
            np.isfinite(
                lambda_actor
            ),
            axis=1,
        )
    )

    eval_local = eval_local[
        valid_rows
    ]

    lambda_actor = lambda_actor[
        valid_rows
    ]

    if len(eval_local) < 2:
        return {}

    # -------------------------------------------------------------------------
    # Worst-client identity
    # -------------------------------------------------------------------------

    worst_ids = np.argmin(
        eval_local,
        axis=1,
    )

    # -------------------------------------------------------------------------
    # Effective number of clients
    # -------------------------------------------------------------------------

    keff = effective_num_clients(
        lambda_actor
    )

    return {
        "worst_switch_full": switch_rate(
            worst_ids
        ),

        "worst_dominant_share_full": dominant_share(
            worst_ids
        ),

        "top1_match_full": tie_aware_top1_match(
            lambda_weights=lambda_actor,
            worst_ids=worst_ids,
        ),

        "keff_full": (
            float(
                np.nanmean(
                    keff
                )
            )
            if np.any(
                np.isfinite(
                    keff
                )
            )
            else np.nan
        ),
    }


# =============================================================================
# Main
# =============================================================================


def main() -> None:
    parser = common_parser(
        "Ablation 04b: compact main-paper table for "
        "worst-environment switching, persistence, "
        "lambda alignment, and effective client count "
        "for AMPO-PPO Uniform and Adaptive variants."
    )

    args = parser.parse_args()

    apply_publication_style()

    validate_expected_layout(
        args.log_root
    )

    # -------------------------------------------------------------------------
    # Output
    # -------------------------------------------------------------------------

    out_dir = (
        args.out_root
        / "04_worst_environment_switching"
    )

    cache_root = (
        args.out_root
        / "_cache"
    )

    # -------------------------------------------------------------------------
    # IMPORTANT
    #
    # 실제 variant names:
    #
    #   ampo_uniform
    #   ampo_adaptive_dual_lr_1e-4
    #   ampo_adaptive_dual_lr_3e-4
    # -------------------------------------------------------------------------

    groups = group_specs(
        args.log_root,
        variants=TRACKING_VARIANTS,
    )

    metric_keys = (
        "worst_switch_full",
        "worst_dominant_share_full",
        "top1_match_full",
        "keff_full",
    )

    csv_rows = []
    latex_rows = []

    # =========================================================================
    # Variant
    # =========================================================================

    for variant in TRACKING_VARIANTS:

        # =====================================================================
        # Environment
        # =====================================================================

        for env in ENV_ORDER:

            # =================================================================
            # Perturbation
            # =================================================================

            for pert in PERTURBATION_ORDER:

                run_specs = get_group_runs(
                    groups,
                    variant,
                    env,
                    pert,
                )

                # -------------------------------------------------------------
                # Useful diagnostic:
                # Uniform이 실제로 발견되는지 바로 확인할 수 있다.
                # -------------------------------------------------------------

                print(
                    f"[Group] "
                    f"variant={variant}, "
                    f"env={env}, "
                    f"pert={pert}, "
                    f"runs={len(run_specs)}"
                )

                loaded = load_group(
                    run_specs,
                    cache_root,
                    force_cache=args.force_cache,
                )

                print(
                    f"[Loaded] "
                    f"variant={variant}, "
                    f"env={env}, "
                    f"pert={pert}, "
                    f"loaded={len(loaded)}"
                )

                seed_metrics = []

                for (
                    spec,
                    run,
                ) in loaded:

                    metrics = per_seed_compact_metrics(
                        run
                    )

                    if metrics:
                        seed_metrics.append(
                            (
                                spec.seed,
                                metrics,
                            )
                        )

                        print(
                            f"  seed={spec.seed}: "
                            f"switch="
                            f"{metrics['worst_switch_full']:.4f}, "
                            f"dominance="
                            f"{metrics['worst_dominant_share_full']:.4f}, "
                            f"top1="
                            f"{metrics['top1_match_full']:.4f}, "
                            f"Keff="
                            f"{metrics['keff_full']:.4f}"
                        )

                # -------------------------------------------------------------
                # Summary across seeds
                # -------------------------------------------------------------

                summaries = {}

                for key in metric_keys:
                    values = [
                        metrics[
                            key
                        ]
                        for (
                            _,
                            metrics,
                        ) in seed_metrics
                    ]

                    summaries[
                        key
                    ] = summarize_seed_values(
                        values
                    )

                # -------------------------------------------------------------
                # LaTeX
                # -------------------------------------------------------------

                cells = [
                    variant_short_name(
                        variant
                    ),

                    DISPLAY_ENV[
                        env
                    ],

                    pert.capitalize(),

                    format_pm(
                        *summaries[
                            "worst_switch_full"
                        ][
                            :2
                        ],
                        digits=2,
                    ),

                    format_pm(
                        *summaries[
                            "worst_dominant_share_full"
                        ][
                            :2
                        ],
                        digits=2,
                    ),

                    format_pm(
                        *summaries[
                            "top1_match_full"
                        ][
                            :2
                        ],
                        digits=2,
                    ),

                    format_pm(
                        *summaries[
                            "keff_full"
                        ][
                            :2
                        ],
                        digits=2,
                    ),
                ]

                latex_rows.append(
                    " & ".join(
                        cells
                    )
                    + r" \\"
                )

                # -------------------------------------------------------------
                # CSV
                # -------------------------------------------------------------

                csv_rows.append(
                    [
                        variant,
                        env,
                        pert,

                        summaries[
                            "worst_switch_full"
                        ][0],

                        summaries[
                            "worst_switch_full"
                        ][1],

                        summaries[
                            "worst_dominant_share_full"
                        ][0],

                        summaries[
                            "worst_dominant_share_full"
                        ][1],

                        summaries[
                            "top1_match_full"
                        ][0],

                        summaries[
                            "top1_match_full"
                        ][1],

                        summaries[
                            "keff_full"
                        ][0],

                        summaries[
                            "keff_full"
                        ][1],

                        summaries[
                            "keff_full"
                        ][2],
                    ]
                )

    # =========================================================================
    # CSV output
    # =========================================================================

    write_csv(
        out_dir
        / "worst_tracking_compact_full_with_keff_uniform_adaptive_summary.csv",

        [
            "variant",
            "environment",
            "perturbation",

            "worst_switch_full_mean",
            "worst_switch_full_std",

            "dominant_worst_share_full_mean",
            "dominant_worst_share_full_std",

            "top1_match_full_mean",
            "top1_match_full_std",

            "keff_full_mean",
            "keff_full_std",

            "num_seeds",
        ],

        csv_rows,
    )

    # =========================================================================
    # LaTeX
    # =========================================================================

    text = make_latex_table_rows(
        [
            "Method",
            "Environment",
            "Perturbation",
            "Worst Switch (Full)",
            "Dominant Worst Share (Full)",
            "Top-1 Match (Full)",
            r"$K_{\mathrm{eff}}$ (Full)",
        ],

        latex_rows,

        comments=[
            (
                "The table includes AMPO-PPO(U) and "
                "all requested AMPO-PPO(A) variants."
            ),

            (
                "All metrics use the full set of matched "
                "evaluation/server points within each seed."
            ),

            (
                "Worst Switch = fraction of consecutive "
                "evaluation points whose eval-worst "
                "client identity changes."
            ),

            (
                "Dominant Worst Share = fraction of evaluations "
                "occupied by the most frequently worst client."
            ),

            (
                "Worst Switch and Dominant Worst Share depend "
                "only on evaluation returns."
            ),

            (
                "Top-1 Match uses tie-aware maximum-lambda "
                "matching."
            ),

            (
                "If m clients share the maximum lambda and the "
                "worst client is in that set, the point "
                "contributes 1/m."
            ),

            (
                "Therefore exact Uniform weighting over K clients "
                "gives Top-1 Match = 1/K."
            ),

            (
                r"$K_{\mathrm{eff}}$ is the mean over matched "
                r"evaluations of "
                r"$1/\sum_k\lambda_{\mathrm{actor},k}^2$."
            ),

            (
                r"Exact Uniform weighting gives "
                r"$K_{\mathrm{eff}}=K$."
            ),

            "Reported as mean +- std across seeds.",
        ],
    )

    write_text(
        out_dir
        / "latex_worst_tracking_compact_full_with_keff_uniform_adaptive_rows.txt",
        text,
    )

    print(
        "\n[LaTeX rows]\n"
        + text
    )

    print(
        "\n[Done] Ablation 04b "
        "Uniform + Adaptive outputs: "
        f"{out_dir}"
    )


if __name__ == "__main__":
    main()